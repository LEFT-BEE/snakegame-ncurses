// #include"function.h"
// #include<deque>
//
// extern MapManager * mapManager;
// class SnakeManager{
//
//     bool isgrow  =false;
//
//     int direc;
//     deque<cell> snake;
//
//     SnakeManager(cell startpoint){
//         snake.push_back(startpoint);
//     }
//
//     ~SnakeManager();
//
//     int head_now(){
//         return mapManager->data[snake.front().tmp.y][snake.front().tmp.x];
//     }
//
//     void addtail(){ //꼬리에 데이터 추가
//         //이후 움직일떄 마지막 데이터 삭제 안해줘도 됨
//         isgrow = true;
//     }
//
//     void removetail(){
//
//         snake.pop_back();
//     }
//
//     void map_push_data(){ // 최종ㅈ적으로 실행되어야 하는 함수 -특히 이동한후 map에 들어가야함!!!!
//       for (int i = 0; i < snake.size(); i++)
//       {
//           if (i == 0)
//           {
//               mapManager->PatchData(snake[i].tmp.y, snake[i].tmp.x, '3');
//           }
//           else
//           {
//               mapManager->PatchData(snake[i].tmp.y, snake[i].tmp.x, '4');
//           }
//       }
//
//     }
//
//
//
// };
