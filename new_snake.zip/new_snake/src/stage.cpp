
#include "stage.h"


Stage::Stage()
{
    nowStage = 0;
    delaytime = 150000;
}

Stage::~Stage()
{
}

void Stage::Update(float eTime)
{
}

void Stage::Render()
{
}
